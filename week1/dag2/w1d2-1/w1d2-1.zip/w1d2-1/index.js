let name = "Dilara Kayhan";
let tien = 10;
let twintig = 20;
let voorNaam = "Dilara";
let achterNaam = "Kayhan";
let mijnLeeftijd = "25";

console.log("Hello Winc Academy");
console.log(name);

// sommetjes
console.log(twintig - tien);
console.log(tien / twintig);
console.log(tien * twintig);
console.log(twintig % tien);
console.log(tien % twintig);

// nummers bij elkaar optellen kan wel
console.log(tien + twintig);

/* 
strings bij elkaar optellen kan niet
console.log(voornaam + achterNaam);
*/

// typeof operator
console.log(typeof mijnLeeftijd);
