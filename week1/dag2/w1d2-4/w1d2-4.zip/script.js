const age = 25;
const isFemale = true;
const driverStatus = "bob";

if (age >= 18) {
  console.log("Je bent oud genoeg om binnen te komen");
} else {
  console.log("Je bent niet oud genoeg om binnen te komen");
}

if (isFemale === true) {
  console.log("Hey girl! Er is vanavond ladiesnight");
} else {
  console.log("Sorry er is vanavond ladiesnight, je mag niet naar binnen.");
}

if (driverStatus == "bob") {
  console.log("Je bent bob! Wat goed van je, je mag rijden");
} else {
  console.log("Je bent onder invloed, je mag niet rijden");
}
