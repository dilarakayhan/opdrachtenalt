console.log("Hallo Winc Academy Studenten");

//dit is een grote som
/*
console.log(1230914 * 1823794);
console.log(637263 / 54); 
*/

// Ik zie alleen Hello Winc Academy Studenten terug in de console omdat de anderen logs in een comment staan, en comments worden niet uitgevoerd.
