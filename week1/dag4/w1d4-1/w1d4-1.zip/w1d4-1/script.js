const firstSection = document.querySelector("#first-section");
// console.log(firstSection);

const paragraph = document.querySelector(".paragraph");
// console.log(paragraph);