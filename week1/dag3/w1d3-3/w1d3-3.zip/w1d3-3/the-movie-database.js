const favMovies = function(title, duration, stars) {
  console.log(title + " lasts for " + duration + " minutes. Stars: " + stars);
};

favMovies("Spirited Away", 120, ["Chihiro, Haku, Yubaba, Zeniba."]);
favMovies("Lord of the Rings", 160, [
  "Elijah Wood, Ian McKellen, Liv Tyler, Viggo Mortensen."
]);
favMovies("Blade Runner", 90, ["Harrison Ford, Rutger Hauer, Sean Young."]);

// the-movie-database.js
