let person = {
  name: "Dilara",
  age: 25,
  evaluations: [7, 10, 9]
};

console.log(person.name);
console.log(person["name"]);
console.log(person.age);
console.log(person["age"]);
console.log(person.evaluations);
console.log(person["evaluations"]);
