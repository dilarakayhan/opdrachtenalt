let colors = ["yellow", "blue", "red", "orange"];
let i = 0;

while (i < colors.length) {
  console.log(colors[i]);
  i++;
}

// while loop neemt 6 regels in beslag
