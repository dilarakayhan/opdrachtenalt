let colors = ["yellow", "blue", "red", "orange"];

for (i = 0; i < colors.length; i++) {
  console.log(colors[i]);
}

// for loop neemt 4 regels in beslag
