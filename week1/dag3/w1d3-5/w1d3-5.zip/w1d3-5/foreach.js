let colors = ["yellow", "blue", "red", "orange"];

colors.forEach(colorArray => console.log(colorArray));

// forEach neemt 2 regels in beslag
