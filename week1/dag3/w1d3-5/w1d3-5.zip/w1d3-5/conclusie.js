let films = [
  "Blade Runner",
  "Lord of the Rings",
  "Spirited Away",
  "Ultraviolet",
  "Resident Evil"
];

films.forEach(favFilms => console.log(favFilms));
