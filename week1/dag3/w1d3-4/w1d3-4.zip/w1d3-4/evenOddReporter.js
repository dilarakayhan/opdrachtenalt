for (i = 0; i <= 20; i++) {
  if (i % 2 == 0) document.write(i + " is an even number. ");
  console.log("A loop to number: " + i);
}

document.write("This has been looped.");
