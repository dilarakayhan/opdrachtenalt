let a;

for (i = 0; i <= 10; i++) {
  a = i * 9;
  console.log(i + " * 9 = " + a);
}

document.write("This has been looped.");
